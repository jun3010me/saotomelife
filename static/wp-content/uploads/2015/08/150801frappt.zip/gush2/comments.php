<div id="comment_box">
<?php if( have_comments() ): // コメントがあったら ?>
<h3 id="comments"><i class="fa fa-comments-o"></i>コメント一覧</h3>
<ol class="commets-list">
<?php wp_list_comments( 'avatar_size=55' ); ?>
</ol>
<?php endif; ?>
<?php $args = array(
	'title_reply' => '<i class="fa fa-pencil-square-o"></i>この記事へのコメントはこちら',
	'label_submit' => 'コメント送信',
	'comment_notes_before' => '<p class="comment-notes">メールアドレスは公開されませんのでご安心ください。<br />また、<span class="required">*</span> が付いている欄は必須項目となりますので、必ずご記入をお願いします。</p>',
	'comment_notes_after'  => '<p class="form-allowed-tags">内容に問題なければ、下記の「コメント送信」ボタンを押してください。</p>',
);
comment_form( $args ); ?>
</div>