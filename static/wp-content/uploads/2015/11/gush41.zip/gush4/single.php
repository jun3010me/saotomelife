<?php get_header(); ?>

<div id="contents"><!-- contentns -->
  <div id="main">
    <div class="article-wrap">
    <article role="main">
      <header>
<!--ループ開始-->
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <p class="date-time"><i class="fa fa-pencil-square-o"></i><time class="entry-date" datetime="<?php the_time('c') ;?>"><?php the_time('Y/m/d') ;?></time>&nbsp;<?php if ($mtime = get_mtime('Y/m/d')) echo '&nbsp;&nbsp;<i class="fa fa-refresh"></i>' , $mtime; ?></p>
        <h1 id="single_title"><?php the_title(); ?></h1>
          <div class="meta-box">
<?php
  $url_encode=urlencode(get_permalink());
  $title_encode=urlencode(get_the_title());
?>
<ul class="sns-button">
  <li class="snsb-tw"><a href="http://twitter.com/intent/tweet?url=<?php echo $url_encode ?>&text=<?php echo $title_encode ?>&tw_p=tweetbutton"><i class="fa fa-twitter fa-fw"></i></a></li>
  <li class="snsb-fa"><a href="http://www.facebook.com/sharer.php?src=bm&u=<?php echo $url_encode;?>&t=<?php echo $title_encode;?>"><i class="fa fa-facebook fa-fw"></i></a></li>
  <li class="snsb-hb"><a href="http://b.hatena.ne.jp/add?mode=confirm&url=<?php echo $url_encode ?>"><span class="hatenabookmark">B!</span></a></li>
  <li class="snsb-gp"><a href="https://plus.google.com/share?url=<?php echo $url_encode;?>"><i class="fa fa-google-plus fa-fw"></i></a></li>
</ul>
          </div><!--//meta_box-->
      </header>
      <div class="article-inner">
      <section>
      <?php the_content(); ?>
      <?php wp_link_pages(); ?>
      </section>

      <div class="cat_tag clear">
        <span><?php the_category(' ') ?></span><span><?php the_tags(' ', ' ', ' '); ?></span>
      </div>
      </div><!--//article-inner-->

      <aside>
      <div class="entry_footer_ad clearfix">
        <?php if(is_mobile()) { ?>
        <?php dynamic_sidebar( 'efa_l' ); ?>
        <?php } else { ?>
        <?php dynamic_sidebar( 'efa_l' ); ?>
        <?php dynamic_sidebar( 'efa_r' ); ?>
        <?php } ?>
      </div><!--//ad-->
      </aside>

<footer role="contentinfo" class="clear">
  <?php breadcrumb(); ?>
  <?php if ( has_post_thumbnail() ): ?>
    <div class="eyecatch" style="background-image: url('<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>')">
  <?php else: ?>
    <div class="no-eyecatch">
  <?php endif; ?>
    <?php get_template_part('sns');?>
    </div>
    <div class="writer-box">
      <div class="writer-image"><?php echo get_avatar( get_the_author_meta( 'ID' ), 180 ); ?></div>
      <div class="writer-info">
        <p>著者：<span class="author"><?php the_author(); ?></span></p>
        <p><?php the_author_meta('description'); ?></p>
        <p class="author-twitter"><a href="https://twitter.com/intent/follow?screen_name=<?php the_author_meta('twitter'); ?>"><i class="fa fa-twitter"></i>Twitterフォロー</a></p>
      </div>
    </div>
</footer>

  <?php endwhile; else: ?>
  <p>記事がありません</p>
  <?php endif; ?>
<!--ループ終了-->
    </article>
    </div><!--//article-wrap-->

    <div class="article-under">
      <!--関連記事-->
      <div class="relations">
<h2 class="rel-title">こちらも読まれています</h2>
<ul class="rel-in">
<?php
	$categories = get_the_category($post->ID);
	$category_ID = array();
	foreach($categories as $category):
	array_push( $category_ID, $category -> cat_ID);
	endforeach ;
	$args = array(
	'post__not_in' => array($post -> ID),
	'posts_per_page'=> 8,
	'category__in' => $category_ID,
	'orderby' => 'rand',
	);
	$st_query = new WP_Query($args); ?>
          <?php
		if( $st_query -> have_posts() ): ?>
          <?php
		while ($st_query -> have_posts()) : $st_query -> the_post(); ?>

<li>
<div class="rel-in-box">
<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
  <div class="rel-child">
    <div class="rel-in-thumb">
    <?php if ( has_post_thumbnail() ): ?>
    <?php echo get_the_post_thumbnail($post->ID, 'thumb90'); ?>
    <?php else: ?>
    <img src="<?php echo get_template_directory_uri(); ?>/images/no-img.png" alt="no image" width="90" height="90"/><?php endif; ?></div>
    <div class="rel-in-title">
      <span class="time-diff"><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . '前の投稿'; ?></span>
      <h3><?php the_title(); ?></h3>
<div class="ms-wrap">
<ul class="mini-sns">
  <li><?php if(function_exists('scc_get_share_total')) echo scc_get_share_total(); ?>&nbsp;Shares</li>
</ul>
</div>
    </div>
  </div>
</a>
</div>
</li>
	<?php endwhile; ?>
	<?php else: ?>
<li class="rel-in-noentry">記事はありませんでした。<a href="<?php echo home_url();?>"><i class="fa fa-arrow-right"></i>ホームページに戻る</a></li>
	<?php endif; wp_reset_postdata(); ?>
</ul>
      </div><!--//relations-->

<!--コメント-->
<?php comments_template(); ?>
<!--//コメント-->

<div class="page-pn">
      <?php
        $prev_post = get_previous_post();
        if (!empty( $prev_post )): ?>
       <dl class="prenex">
       <dt>前の記事</dt><dd><a href="<?php echo get_permalink( $prev_post->ID ); ?>"><?php echo $prev_post->post_title; ?></a></dd>
       </dl>
      <?php endif; ?>
      <?php
        $next_post = get_next_post();
        if (!empty( $next_post )): ?>
       <dl class="prenex">
       <dt>次の記事</dt><dd><a href="<?php echo get_permalink( $next_post->ID ); ?>"><?php echo $next_post->post_title; ?></a></dd>
       </dl>
      <?php endif; ?>
</div><!--//page_pn-->

    </div><!--//article-under-->
  </div><!--//main-->

<?php get_sidebar(); ?>
<?php get_footer(); ?>