</div><!--//contents-->

<!-- footer -->
<div id="footer">
<footer>

<!--フッター分岐-->
<?php if(is_mobile()) { ?>

<!--スマホ表示エリア-->
<ul class="top-home">
  <li><a href="#header"><i class="fa fa-arrow-up"></i><br /><span class="top-home-txt">TOP</span></a></li>
  <li><a href="<?php echo home_url();?>"><i class="fa fa-home"></i><br /><span class="top-home-txt">HOME</span></a></li>
</ul>
<!--//スマホ表示エリア-->

<?php } else { ?>

<!--PC3列 タブレット1+2列-->
<div class="footer-wrap">
  <div class="footer-in">
  <!--フッター左-->
    <div class="footer_l">
      <?php dynamic_sidebar( 'footer_left' ); ?>
    </div><!--//footer_l-->
  <!--フッター中-->
    <div class="footer_c">
      <ul>
      <?php dynamic_sidebar( 'footer_center' ); ?>
      </ul>
    </div><!--//footer_c-->
  <!--フッター右-->
      <div class="footer_r">
      <ul>
      <?php dynamic_sidebar( 'footer_right' ); ?>
      </ul>
    </div><!--//footer_r-->
  </div><!--//footer-in-->
</div>
<!--//PC・タブレットエリア-->
<?php } ?>

<div class="footer-bottom">
  <p><small>&copy;<?php echo date('Y'); ?> <?php bloginfo('name'); ?></small></p>
  <p class="gush_link"><small>WordPress Theme Gush4</small></p>
</div>

</footer>
</div>
<!-- //footer -->

<?php wp_footer(); ?>
<!-- ページトップへ スマホ非表示 -->
<?php if(is_mobile()) { ?>
<?php } else { ?>
<div id="page-top"><a href="#header"><i class="fa fa-arrow-up"></i>
</a></div>
<?php } ?>
<!-- //ページトップへ-->
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.sidr.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/gush.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/right-height.min.js"></script>
<script>
  rightHeight.init();
</script>
<!--Twitter-->
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
<!--Google+1-->
<script src="https://apis.google.com/js/platform.js" async defer>
  {lang: 'ja'}
</script>
<!--はてなブックマーク-->
<script type="text/javascript" src="http://b.st-hatena.com/js/bookmark_button.js" charset="utf-8" async="async"></script>
</body>
</html>