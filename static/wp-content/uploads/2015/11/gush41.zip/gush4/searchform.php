<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
    <div>
        <input type="text" value="" name="s" id="s" placeholder="キーワード検索" />
        <button type="submit" id="searchsubmit"><i class="fa fa-search"></i></button>
    </div>
</form>