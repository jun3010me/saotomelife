<?php
/*
Template Name: 幅狭1カラム
*/
get_header(); ?>

<div id="contents"><!-- contentns -->
  <div id="main-narrow">
    <div class="article-wrap">
    <article role="main">
      <div class="article-inner">

      <header>
<!--ループ開始-->
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <h1 id="single_title"><?php the_title(); ?></h1>
      </header>
      <section>
<?php the_content(); ?>
<?php wp_link_pages(); ?>
      </section>
  <?php endwhile; else: ?>
  <p>記事がありません</p>
  <?php endif; ?>
      </div><!--//article-inner-->
  <!--ループ終了-->

<?php if(!is_home()): ?>
<footer role="contentinfo" class="clear">
  <div class="page-footer">
    <?php breadcrumb(); ?>
  </div>
</footer>
<?php else: ?>
<?php endif; ?>
     
    </article>
    </div><!--//article-wrap-->

  </div><!--//main-->

<?php get_footer(); ?>