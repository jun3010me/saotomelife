<div class="article-snsbox"><!--SNS-->
<ul>
  <li><a href="https://twitter.com/share" class="twitter-share-button"{count} data-via="<?php the_author_meta('twitter'); ?>" data-url="<?php the_permalink(); ?>" data-size="large">Tweet</a></li>
  <li><div class="fb-share-button" data-href="<?php the_permalink(); ?>" data-layout="box_count"></div></li>
  <li><div class="g-plusone" data-size="tall"></div></li>
  <li><a href="http://b.hatena.ne.jp/entry/<?php the_permalink(); ?>" class="hatena-bookmark-button" data-hatena-bookmark-title="<?php the_title(); ?>｜<?php bloginfo('name'); ?>" data-hatena-bookmark-layout="vertical-balloon" title="このエントリーをはてなブックマークに追加"><img src="https://b.st-hatena.com/images/entry-button/button-only@2x.png" alt="このエントリーをはてなブックマークに追加" width="20" height="20" /></a></li>
</ul>
</div><!--//SNS-->