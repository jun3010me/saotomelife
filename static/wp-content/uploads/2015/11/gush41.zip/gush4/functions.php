<?php

//jQuery読み込み
function load_script(){
    wp_enqueue_script( 'jquery' );
}
add_action( 'init', 'load_script' );

//タイトル出力
add_theme_support( 'title-tag' );

//カスタムメニュー
register_nav_menus(array(
'globalnavi'=>'左スライドメニュー',
'pcnavi'=>'ヘッダー（PC・タブレット）',
'mobilenavi'=>'ヘッダー（スマホ）'
));

//アイキャッチサムネイル生成
if (function_exists( 'add_theme_support' )) {
add_theme_support( 'post-thumbnails' );
add_image_size( 'thumb90', 180, 180, true );
add_image_size( 'thumb600', 600, 300, true );
}

//RSS出力
add_theme_support( 'automatic-feed-links' );

//エディタスタイル
add_theme_support( 'editor-style' );
add_editor_style( 'css/editor-style.css' );
function custom_editor_settings( $initArray ){
	$initArray['body_class'] = 'editor-area';
	return $initArray;
}
add_filter( 'tiny_mce_before_init', 'custom_editor_settings' );

//カスタム背景
add_theme_support( 'custom-background' );

//ヘッダー整理
remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'feed_links', 2 );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'index_rel_link' );
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
remove_action( 'wp_head', 'wp_generator' );

// パンくずリスト
function breadcrumb() {
  global $post;
  $format = '<li itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a>&nbsp;&nbsp;&gt;</li>';
  $str ='';
  if (!is_home()&&!is_admin()) {
      $str.= '<div id="breadcrumb" class="clearfix"><ul>';
      $str.=  sprintf($format, esc_url(home_url('/')), HOME);
         
      if(is_search()){
          $str.='<li>「'. get_search_query() .'」で検索した結果</li>';
      } elseif(is_tag()){
          $str.='<li>タグ : '. single_tag_title( '' , false ). '</li>';
      } elseif(is_404()){
          $str.='<li>404 Not found</li>';
      } elseif(is_date()){
          if(get_query_var('day') != 0){
              $str.= sprintf($format, esc_url(get_year_link(get_query_var('year'))), get_query_var('year') . '年');
              $str.= sprintf($format, esc_url(get_month_link(get_query_var('year'), get_query_var('monthnum'))), get_query_var('monthnum') . '月');
              $str.='<li>'. get_query_var('day'). '日</li>';
          } elseif(get_query_var('monthnum') != 0){
              $str.= sprintf($format, esc_url(get_year_link(get_query_var('year'))), get_query_var('year') . '年');
              $str.='<li>'. get_query_var('monthnum'). '月</li>';
          } else {
              $str.='<li>'. get_query_var('year') .'年</li>';
          }
      } elseif(is_category()) {
          $cat = get_queried_object();
          if($cat -> parent != 0){
              $ancestors = array_reverse(get_ancestors( $cat -> cat_ID, 'category' ));
              foreach($ancestors as $ancestor){
                  $str.= sprintf($format, esc_url(get_category_link($ancestor)), get_cat_name($ancestor));
              }
          }
          $str.='<li>'. $cat -> name . '</li>';
      } elseif(is_author()){
          $str .='<li>投稿者 : '. get_the_author_meta('display_name', get_query_var('author')).'</li>';
      } elseif(is_page()){
          if($post -> post_parent != 0 ){
              $ancestors = array_reverse(get_post_ancestors( $post->ID ));
              foreach($ancestors as $ancestor){
                  $str.= sprintf($format, esc_url(get_permalink($ancestor)), get_the_title($ancestor));
              }
          }
          $str.= '<li>'. $post -> post_title .'</li>';
           
      } elseif(is_attachment()){
          if($post -> post_parent != 0 ){
             $str.= sprintf($format, esc_url(get_permalink($post -> post_parent)), get_the_title($post -> post_parent));
          }
          $str.= '<li>' . $post -> post_title . '</li>';
      } elseif(is_single()){
          $categories = get_the_category($post->ID);
          $cat = $categories[0];
          if($cat -> parent != 0){
              $ancestors = array_reverse(get_ancestors( $cat -> cat_ID, 'category' ));
              foreach($ancestors as $ancestor){
                  $str.= sprintf($format, esc_url(get_category_link($ancestor)), get_cat_name($ancestor));
              }
          }
          $str.= sprintf($format, esc_url(get_category_link($cat -> term_id)), $cat-> cat_name);
          $str.= '<li>'. $post -> post_title .'</li>';
      } else{
          $str.='<li>'. wp_title('', false) .'</li>';
      }
      $str.='</ul></div>';
  }
  echo $str;
}

//ウイジェット追加
if (function_exists('register_sidebar')) {

//ヘッダー下部
register_sidebar( array(
     'name' => __( 'ヘッダー下' ),
     'id' => 'head-under',
     'description'   => 'レスポンシブデザイン用AdSense推奨',
     'before_widget' => '<div class="head-under-widget">',
     'after_widget' => '</div>',
     'before_title' => '',
     'after_title' => '',
) );

//サイドバー左
register_sidebar( array(
     'name' => __( 'サイドバー左' ),
     'id' => 'side-left-widget',
     'description'   => 'タブレット表示のみサイドバーが左右にわかれます。こちらは左側',
     'before_widget' => '<li>',
     'after_widget' => '</li>',
     'before_title' => '<h2>',
     'after_title' => '</h2>',
) );

//サイドバー右
register_sidebar( array(
     'name' => __( 'サイドバー右' ),
     'id' => 'side-right-widget',
     'description'   => 'タブレット表示のみサイドバーが左右にわかれます。こちらは右側',
     'before_widget' => '<li>',
     'after_widget' => '</li>',
     'before_title' => '<h2>',
     'after_title' => '</h2>',
) );

//サイドバー300px広告
register_sidebar( array(
     'name' => __( 'サイド広告300px' ),
     'id' => 'side-ad',
     'description'   => '404ページ規約違反回避のためAdSense以外推奨。タブレット表示は左側',
     'before_widget' => '<div>',
     'after_widget' => '</div>',
     'before_title' => '',
     'after_title' => '',
) );

//記事下左300広告
register_sidebar( array(
     'name' => __( '記事下左300px' ),
     'id' => 'efa_l',
     'before_widget' => '<div class="efa_left">',
     'after_widget' => '</div>',
     'before_title' => '',
     'after_title' => '',
) );

//記事下右300広告
register_sidebar( array(
     'name' => __( '記事下右300px' ),
     'id' => 'efa_r',
     'description'   => 'スマホでは出力されません',
     'before_widget' => '<div class="efa_right">',
     'after_widget' => '</div>',
     'before_title' => '',
     'after_title' => '',
) );

//フッター左
register_sidebar( array(
     'name' => __( 'フッター左' ),
     'id' => 'footer_left',
     'before_widget' => '<div>',
     'after_widget' => '</div>',
     'before_title' => '<h2>',
     'after_title' => '</h2>',
) );

//フッター中央
register_sidebar( array(
     'name' => __( 'フッター中' ),
     'id' => 'footer_center',
     'before_widget' => '<li>',
     'after_widget' => '</li>',
     'before_title' => '<h3>',
     'after_title' => '</h3>',
) );

//フッター右
register_sidebar( array(
     'name' => __( 'フッター右' ),
     'id' => 'footer_right',
     'before_widget' => '<li>',
     'after_widget' => '</li>',
     'before_title' => '<h3>',
     'after_title' => '</h3>',
) );
}

//更新日の追加
function get_mtime($format) {
    $mtime = get_the_modified_time('Ymd');
    $ptime = get_the_time('Ymd');
    if ($ptime > $mtime) {
        return get_the_time($format);
    } elseif ($ptime === $mtime) {
        return null;
    } else {
        return get_the_modified_time($format);
    }
}

//スマホ表示分岐
function is_mobile(){
    $useragents = array(
        'iPhone', // iPhone
        'iPod', // iPod touch
        'Android.*Mobile', // 1.5+ Android *** Only mobile
        'Windows.*Phone', // *** Windows Phone
        'dream', // Pre 1.5 Android
        'CUPCAKE', // 1.5+ Android
        'blackberry9500', // Storm
        'blackberry9530', // Storm
        'blackberry9520', // Storm v2
        'blackberry9550', // Storm v2
        'blackberry9800', // Torch
        'webOS', // Palm Pre Experimental
        'incognito', // Other iPhone browser
        'webmate' // Other iPhone browser

    );
    $pattern = '/'.implode('|', $useragents).'/i';
    return preg_match($pattern, $_SERVER['HTTP_USER_AGENT']);
}

// コメントフォームタグ削除
add_filter( "comment_form_defaults", "my_comment_notes_after");
function my_comment_notes_after( $defaults){
    $defaults['comment_notes_after'] = '';
    return $defaults;
}

//Youtube対応
function wrap_iframe_in_div($the_content) {
  if ( is_singular() ) {
    $the_content = preg_replace('/<iframe/i', '<div class="video-container"><iframe', $the_content);
    $the_content = preg_replace('/<\/iframe>/i', '</iframe></div>', $the_content);
  }
  return $the_content;
}
add_filter('the_content','wrap_iframe_in_div');

//管理画面お問い合わせリンク
function custom_admin_footer() {
    echo 'Gush4ご利用に関するお問い合わせは<a href="http://naifix.com/contact/" target="_blank">こちら</a>まで';
}
add_filter('admin_footer_text', 'custom_admin_footer');

//プロフィール項目追加
function my_new_contactmethods( $contactmethods ) {
$contactmethods['twitter'] = 'Twitter';
$contactmethods['facebook'] = 'Facebook';
$contactmethods['googleplus'] = 'Google+';
return $contactmethods;
}
add_filter('user_contactmethods','my_new_contactmethods',10,1);

//記事ごとのCSS
add_action('admin_menu', 'custom_css_hooks');
add_action('save_post', 'save_custom_css');
add_action('wp_head','insert_custom_css');
function custom_css_hooks() {
	add_meta_box('custom_css', 'Custom CSS', 'custom_css_input', 'post', 'normal', 'high');
	add_meta_box('custom_css', 'Custom CSS', 'custom_css_input', 'page', 'normal', 'high');
}
function custom_css_input() {
	global $post;
	echo '<input type="hidden" name="custom_css_noncename" id="custom_css_noncename" value="'.wp_create_nonce('custom-css').'" />';
	echo '<textarea name="custom_css" id="custom_css" rows="5" cols="30" style="width:100%;">'.get_post_meta($post->ID,'_custom_css',true).'</textarea>';
}
function save_custom_css($post_id) {
	if (!wp_verify_nonce($_POST['custom_css_noncename'], 'custom-css')) return $post_id;
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;
	$custom_css = $_POST['custom_css'];
	update_post_meta($post_id, '_custom_css', $custom_css);
}
function insert_custom_css() {
	if (is_page() || is_single()) {
		if (have_posts()) : while (have_posts()) : the_post();
			echo '<style type="text/css">'.get_post_meta(get_the_ID(), '_custom_css', true).'</style>';
		endwhile; endif;
		rewind_posts();
	}
}