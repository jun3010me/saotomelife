<?php get_header(); ?>

<div id="contents"><!-- contentns -->
  <div id="main">
    <div class="article-wrap">
    <article role="main">
      <div class="article-inner">

      <header>
        <h1 id="single_title">404－お探しのページは見つかりませんでした</h1>
      </header>
      <section>
<img src="<?php echo get_template_directory_uri(); ?>/images/sorry-404.jpg" alt="404" width="600" height="400" style="margin-bottom: 36px" />
<p>大変申し訳ありません。こちらの記事は削除されているか、存在しないページのようです。</p>
<ul>
<li><a href="<?php echo home_url();?>" title="<?php bloginfo('name'); ?>">ホームページに戻る</a></li>
</ul>
      </section>
      </div><!--//article-inner-->
    </article>
    </div><!--//article-wrap-->

  </div><!--//main-->

<?php get_sidebar(); ?>
<?php get_footer(); ?>