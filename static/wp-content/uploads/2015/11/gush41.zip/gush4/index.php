<?php get_header(); ?>

<div id="contents"><!-- contentns -->
  <div id="main" role="main">

  <?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>

    <div class="home_area">

      <section>
        <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <div class="thumb_box">
          <?php if ( has_post_thumbnail() ): ?>
          <?php the_post_thumbnail( 'thumb90' ); ?>
          <?php else: ?>
          <img src="<?php echo get_template_directory_uri(); ?>/images/no-img.png" alt="no image" width="90" height="90" />
          <?php endif; ?>
        </div><!--//thumb_box-->
        <div class="entry_box">
          <span class="date-time"><?php the_time('Y/m/d') ?></span><span class="eb_cat"><i class="fa fa-folder-open-o"></i><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span>
          <h3 class="new_entry_title"><?php the_title(); ?></h3>
<div class="ms-wrap">
<ul class="mini-sns">
  <li><?php if(function_exists('scc_get_share_total')) echo scc_get_share_total(); ?>&nbsp;Shares</li>
</ul>
</div>
        </div>
        </a>
      </section>
    </div><!--//home_area-->

    <?php endwhile; else: ?>
    <div class="home_area">
      <p>記事がありません</p>
    </div>
    <?php endif; ?>

      <aside>
      <div class="entry_footer_ad clearfix">
        <?php if(is_mobile()) { ?>
        <?php dynamic_sidebar( 'efa_l' ); ?>
        <?php } else { ?>
        <?php dynamic_sidebar( 'efa_l' ); ?>
        <?php dynamic_sidebar( 'efa_r' ); ?>
        <?php } ?>
      </div><!--//ad-->
      </aside>

  <!--ページナビ-->
  <div class="pager">
	<?php global $wp_rewrite;
	$paginate_base = get_pagenum_link(1);
	if(strpos($paginate_base, '?') || ! $wp_rewrite->using_permalinks()){
		$paginate_format = '';
 		$paginate_base = add_query_arg('paged','%#%');
	}
	else{
		$paginate_format = (substr($paginate_base,-1,1) == '/' ? '' : '/') .
		user_trailingslashit('page/%#%/','paged');;
		$paginate_base .= '%_%';
	}
	echo paginate_links(array(
		'base' => $paginate_base,
		'format' => $paginate_format,
		'total' => $wp_query->max_num_pages,
		'mid_size' => 4,
		'current' => ($paged ? $paged : 1),
		'prev_text' => '≪',
		'next_text' => '≫',
	)); ?>
  </div>

  <!-- メイン下部 -->
  <?php dynamic_sidebar( 'main-bottom' ); ?>
  <!-- //メイン下部 -->

  </div><!--//main-->

<?php get_sidebar(); ?>
<?php get_footer(); ?>