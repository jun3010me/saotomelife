<!DOCTYPE HTML>
<html lang="ja">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" />
<link href='https://fonts.googleapis.com/css?family=Khula:300' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js" charset="UTF-8"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/css3-mediaqueries.js" charset="UTF-8"></script>
<![endif]-->
<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>
<!--Facebook-->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.4";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="head-wrap">
<div id="header"><!-- header -->
  <header>
    <div id="mobile">
      <div class="menu-button">
      <a id="sidr-menu-button" href="#sidr-nav"><span class="menutxt">メニュー</span><br /><i class="fa fa-list-ul"></i></a>
      </div>
    </div>
    <nav class="head-nav" role="navigation">
      <?php wp_nav_menu( array(
        'theme_location'=>'globalnavi',
        'container'     =>'',
	'menu_class'    => 'g-navi'
        ));
      ?>
    </nav>
    <div class="hgroup" role="banner">
      <h1 class="top_title"><a href="<?php echo home_url();?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>
      <h2 class="caption"><?php bloginfo('description'); ?></h2>
    </div>
    <!--スマホ／タブレット・PCメニュー-->
    <?php if(is_mobile()) { ?>
    <nav class="head-nav-mobi">
      <?php wp_nav_menu( array(
        'theme_location'=>'mobilenavi',
        'container'     =>'',
	'menu_class'    => 'm-navi'
        ));
      ?>
    </nav>
    <?php } else { ?>
    <nav class="head-nav-pc">
      <?php wp_nav_menu( array(
        'theme_location'=>'pcnavi',
        'container'     =>'',
	'menu_class'    => 'pc-navi'
        ));
      ?>
    </nav>
    <?php } ?>
  </header>
</div><!-- //header -->
</div><!-- //head-wrap -->

<!-- ヘッダー下ウィジェット -->
<?php dynamic_sidebar( 'head-under' ); ?>