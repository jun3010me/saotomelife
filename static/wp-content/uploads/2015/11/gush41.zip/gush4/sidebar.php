<!--sub-->
<div id="sub">
<aside>

<!--ここからサイドバー左（タブレット）-->
<div class="side-left">

<!--アイコン-->
<div class="side-sns">
<h2>Follow</h2>
<ul>
<li><a href="https://twitter.com/<?php the_author_meta('twitter'); ?>" target="_blank" class="sns-tw"><i class="fa fa-twitter"></i><br /><span class="sns-txt">Twitter</span></a></li>
<li><a href="https://www.facebook.com/<?php the_author_meta('facebook'); ?>" target="_blank" class="sns-fa"><i class="fa fa-facebook"></i><br /><span class="sns-txt">Facebook</span></a></li>
<li><a href="https://plus.google.com/+<?php the_author_meta('googleplus'); ?>" target="_blank" class="sns-gp"><i class="fa fa-google-plus"></i><br /><span class="sns-txt">Google+</span></a></li>
<li><a href="<?php echo home_url();?>/feed/" target="_blank" class="feed-reg"><i class="fa fa-rss"></i><br /><span class="sns-txt">RSS feed</span></a></li>
</ul>
</div>

<!--広告-->
<div class="side-ad">
<?php dynamic_sidebar( 'side-ad' ); ?>
</div>

<!--ウィジェット（サイドバー左）-->
<div class="side-contents">
<ul class="side_widget">
<?php dynamic_sidebar( 'side-left-widget' ); ?>
</ul>
</div><!--//side_contents-->

</div><!--//サイドバー左ここまで-->

<!--ここからサイドバー右-->
<div class="side-right">

<!--ウィジェット（サイドバー右）-->
<div class="side-contents">
<ul class="side_widget">
<?php dynamic_sidebar( 'side-right-widget' ); ?>
</ul>
</div><!--//side_contents-->

<!--新着記事・ホーム非表示-->
<?php if(is_home()): ?>
<?php else: ?>
<div class="side-contents">
<h2>NEWエントリー</h2>
<?php
$args = array(
    'posts_per_page' => 10,
);
$st_query = new WP_Query($args);
?>

<?php if( $st_query->have_posts() ): ?>
<?php while ($st_query->have_posts()) : $st_query->the_post(); ?>
<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" class="side-link">
  <div class="side-new">
    <div class="side-thumb">
	<?php if ( has_post_thumbnail() ): // サムネイルを持っているときの処理 ?>
	<?php the_post_thumbnail( 'thumb90' ); ?>
	<?php else: // サムネイルを持っていないときの処理 ?>
	<img src="<?php echo get_template_directory_uri(); ?>/images/no-img.png" alt="no image" width="90" height="90" />
	<?php endif; ?>
    </div>
    <div class="side-title">
      <span><?php echo get_post_time('Y.m.d D'); ?></span>
      <h3><?php the_title(); ?></h3>
    </div>
  </div></a><!--//side-new-->
<?php endwhile; ?>
<?php else: ?>
  <p>記事はありませんでした</p>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
</div><!--//side-contents-->
<?php endif; ?>
<!--新着記事ここまで-->

</div><!--サイドバー右ここまで-->
</aside>
</div><!--//sub-->