<div class="comment-wrap">
  <?php if( have_comments() ): ?>
  <h2 class="comment-title">この記事へのコメント</h2>
  <h3 class="comment-list-title">コメント一覧</h3>
    <ol class="comment-list">
      <?php wp_list_comments( 'avatar_size=55' ); ?>
    </ol>
  <?php endif; ?>
  <?php $args = array(
	'title_reply' => 'コメント投稿',
	'label_submit' => 'コメント送信',
	'comment_notes_before' => '<p>※メールアドレスは公開されません。<br />※<span class="required">*</span> が付いている欄は必須項目です。</p>',
	'comment_notes_after'  => '<p>内容に問題なければ、下記の「コメント送信」ボタンを押してください。</p>',
  );
  comment_form( $args ); ?>
</div>