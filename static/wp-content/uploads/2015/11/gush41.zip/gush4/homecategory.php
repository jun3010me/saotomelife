<?php
/*
Template Name: カテゴリー別ホームページ
*/
get_header(); ?>

<div id="contents"><!-- contentns -->
  <div id="main-cat">

<div class="top-entry"><!--最新1＋新着3-->
  <div class="brandnew-list">
    <h2>最新記事</h2>
    <!--ここから最新記事1件-->
    <?php
    $postslist = get_posts('numberposts=1&orderby=post_date&order=DESC"');
    foreach ($postslist as $post) : setup_postdata($post);
    ?>
    <a href="<?php the_permalink();?>">
    <div class="latest">
      <div class="latest-ttl">
        <span class="date-time"><?php the_time('Y.m.d') ?></span>
        <span class="eb_cat"><i class="fa fa-folder-open-o"></i><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span>
        <h3><?php the_title(); ?></h3>
<div class="ms-wrap">
<ul class="mini-sns">
  <li><?php if(function_exists('scc_get_share_total')) echo scc_get_share_total(); ?>&nbsp;Shares</li>
</ul>
</div>
      </div><!--//latest-ttl-->
      <div class="latest-thumb">
        <?php if ( has_post_thumbnail() ): ?>
        <?php the_post_thumbnail( 'thumb600' ); ?>
        <?php else: ?>
        <img src="<?php echo get_template_directory_uri(); ?>/images/latest-no-img.jpg" alt="no image" width="600" height="300" />
        <?php endif; ?>
      </div><!--//latest-thumb-->
    <?php endforeach; ?>
    <?php wp_reset_postdata(); ?>
    </div><!--//latest-->
    </a>
  </div><!--//brandnew-list-->
  <!--//最新記事1件ここまで-->

  <!--新着記事3件ここから-->
  <div class="new-list">
    <h2>新着記事</h2>
    <?php
    $postslist = get_posts('numberposts=3&offset=1&orderby=post_date&order=DESC"');
    foreach ($postslist as $post) : setup_postdata($post);
    ?>
    <div class="home_area">
        <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <div class="thumb_box">
          <?php if ( has_post_thumbnail() ): // ?>
          <?php the_post_thumbnail( 'thumb90' ); ?>
          <?php else: ?>
          <img src="<?php echo get_template_directory_uri(); ?>/images/no-img.png" alt="no image" width="90" height="90" />
          <?php endif; ?>
        </div><!--//thumb_box-->
        <div class="entry_box">
          <span class="date-time"><?php the_time('Y/m/d') ?></span><span class="eb_cat"><i class="fa fa-folder-open-o"></i><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span>
          <h3 class="new_entry_title"><?php the_title(); ?></h3>
<div class="ms-wrap">
<ul class="mini-sns">
  <li><?php if(function_exists('scc_get_share_total')) echo scc_get_share_total(); ?>&nbsp;Shares</li>
</ul>
</div>
        </div>
        </a>
    </div><!--//home_area-->
    <?php endforeach; ?>
    <?php wp_reset_postdata(); ?>
  </div><!--new-list-->
  <!--//新着記事3件ここまで-->
</div><!--//top-entry-->

<!--ここからカテゴリー別新着記事-->
<div class="clearfix" data-right-height>
<?php
$categories = get_categories('parent=0');
foreach($categories as $category) :
?>
<div class="category-article" data-right-height-content>
<h2><?php echo $category->cat_name; ?><span>の記事</span></h2>
<?php
$args = array(
    'cat' => $category->cat_ID,
    'posts_per_page' => 3 // 件数の調整
);
$query = new WP_Query( $args );
if ( $query ->have_posts() ) :
while ( $query ->have_posts() ) : 
$query ->the_post();
?>
    <div class="home_area">
        <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
        <div class="thumb_box">
          <?php if ( has_post_thumbnail() ): // ?>
          <?php the_post_thumbnail( 'thumb90' ); ?>
          <?php else: ?>
          <img src="<?php echo get_template_directory_uri(); ?>/images/no-img.png" alt="no image" width="90" height="90" />
          <?php endif; ?>
        </div><!--//thumb_box-->
        <div class="entry_box">
          <span class="date-time"><?php the_time('Y/m/d') ?></span><span class="eb_cat"><i class="fa fa-folder-open-o"></i><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span>
          <h3 class="new_entry_title"><?php the_title(); ?></h3>
<div class="ms-wrap">
<ul class="mini-sns">
  <li><?php if(function_exists('scc_get_share_total')) echo scc_get_share_total(); ?>&nbsp;Shares</li>
</ul>
</div>
        </div>
        </a>
    </div><!--//home_area-->
<?php endwhile; endif; ?>
<div class="cat-page-link">
<span><i class="fa fa-arrow-circle-o-right"></i><a href="<?php echo get_category_link( $category->term_id ); ?>"><?php echo $category->cat_name; ?>の記事一覧</a></span>
</div>
</div><!--//.category-article-->
<?php endforeach; ?>
</div>
<!--//カテゴリー別新着記事ここまで-->

<?php wp_reset_query(); ?>
  </div><!--//main-cat-->

<?php get_footer(); ?>