<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

use Inc2734\WP_OEmbed_Blog_Card\OEmbed_Blog_Card;

new OEmbed_Blog_Card();
