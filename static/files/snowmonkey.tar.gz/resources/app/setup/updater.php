<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

use Inc2734\WP_GitHub_Theme_Updater\GitHub_Theme_Updater;

$updater = new GitHub_Theme_Updater( get_template(), 'inc2734', 'snow-monkey' );
