<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

use Inc2734\WP_Contents_Outline\Contents_Outline;

add_filter( 'inc2734_wp_contents_outline_enqueue_js', '__return_false' );

new Contents_Outline();
