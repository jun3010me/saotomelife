<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

add_action( 'after_setup_theme', function() {
	add_theme_support( 'woocommerce' );
} );
