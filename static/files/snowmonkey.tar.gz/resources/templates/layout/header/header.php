<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

wpvc_get_header_template( get_theme_mod( 'header-layout' ) );
