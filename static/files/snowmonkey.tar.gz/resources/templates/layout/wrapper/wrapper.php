<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

wpvc_get_wrapper_template( 'right-sidebar' );
