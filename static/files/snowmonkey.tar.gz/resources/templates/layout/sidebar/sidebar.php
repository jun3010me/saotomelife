<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

do_action( 'snow_monkey_sidebar' );
