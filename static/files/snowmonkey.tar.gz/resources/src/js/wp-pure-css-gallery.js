'use strict';

import Inc2734_WP_Pure_CSS_Gallery from '../../vendor/inc2734/wp-pure-css-gallery/src/assets/js/wp-pure-css-gallery.js';
new Inc2734_WP_Pure_CSS_Gallery();
