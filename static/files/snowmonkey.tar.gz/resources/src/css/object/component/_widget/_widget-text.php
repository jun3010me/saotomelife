<?php
/**
 * @package snow-monkey
 * @author inc2734
 * @license GPL-2.0+
 */

snow_monkey_entry_content_styles( [ '.textwidget' ] );
